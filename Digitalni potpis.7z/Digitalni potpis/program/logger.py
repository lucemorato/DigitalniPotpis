import logging
import colorama
from colorama import Fore, Back, Style


colorama.init(autoreset=True)

class ColoredFormatter(logging.Formatter):
  __colors = {
    'DEBUG': Fore.BLUE,
    'INFO': Fore.CYAN,
    'WARNING': Fore.YELLOW,
    'ERROR': Fore.RED,
    'CRITICAL': Fore.MAGENTA,

    'LIGHT_WHITE': Fore.LIGHTBLACK_EX
  }

  def format(self, record):
    msg = logging.Formatter.format(self, record)

    if record.levelname in self.__colors:
      # msg = self.__colors[record.levelname] + msg + Fore.RESET
      message_parts = msg.split(':')
      asctime = message_parts[0] + ':' + message_parts[1] + ':' + message_parts[2]
      levelname = message_parts[3]
      name = message_parts[4]
      message = ':'.join(message_parts[5:])

      msg = self.__colors['LIGHT_WHITE'] + asctime + ':' \
        + self.__colors[record.levelname] + levelname + ':' \
        + self.__colors['LIGHT_WHITE'] + name + ':' \
        + Fore.RESET + message
    
    return msg

logger = logging.getLogger('main')
handler = logging.StreamHandler()
handler.setFormatter(ColoredFormatter('%(asctime)s:%(levelname)s:%(name)s:%(message)s'))
logger.addHandler(handler)
logger.setLevel(logging.DEBUG)

reader_observer_logger = logging.getLogger('observer.reader')
reader_observer_logger.addHandler(handler)
reader_observer_logger.setLevel(logging.DEBUG)
card_observer_logger = logging.getLogger('observer.card')
card_observer_logger.addHandler(handler)
card_observer_logger.setLevel(logging.DEBUG)
card_connection_observer_logger = logging.getLogger('observer.cardconnection')
card_connection_observer_logger.addHandler(handler)
card_connection_observer_logger.setLevel(logging.DEBUG)
card_command_logger = logging.getLogger('cardcommand')
card_command_logger.addHandler(handler)
card_command_logger.setLevel(logging.DEBUG)
