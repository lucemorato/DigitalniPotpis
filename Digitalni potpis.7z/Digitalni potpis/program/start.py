import hashlib
import sys

# Importiramo modul za deserijalizaciju PEM endkodiranih podataka.
from cryptography import x509
import binascii  # Importiramo modul za konvereziju između binary i ASCII koda.
import PyKCS11  # Importiramo PyKCS11 modul.
from logger import logger


# location of pkcs11 library (comes with the GUI application - check in installation folder)

# Pokazujemo pykcs modulu gdje se nalazi "vendor specific" pkcs biblioteka
pykcs11_lib = 'C:\\Program Files\\AKD\\eID Middleware\\pkcs11\\AkdEidPkcs11_64.dll'
# Tekst ili podatak za potpis
data_to_sign = b'Potpisi me majstore!'

# Potrebno doraditi
# BUF_SIZE = 65536  # Čitamo podatke iz filea u djelovima od 64KB
# md5 = hashlib.md5()
# sha1 = hashlib.sha1()

# with open(sys.argv[1], 'rb') as f:
#     while True:
#         data = f.read(BUF_SIZE)
#         if not data:
#             break
#         md5.update(data)
#         sha1.update(data)

# print("MD5: {0}".format(md5.hexdigest()))
# print("SHA1: {0}".format(sha1.hexdigest()))


# load all known CKA keys (keys that keep information on data red form a token (card))

# Učitaj sva dostupna CKA polja (CKA polja sadrže atribute koje možemo dohvatiti sa kartice)
# Napomena da nemaju sve smart kartice identična CKA polja
all_attr = list(PyKCS11.CKA.keys())
all_attr = [e for e in all_attr if isinstance(e, int)]


# load targeted library

#Učitaj "vendor specific" pkcs modul
pkcs11 = PyKCS11.PyKCS11Lib()
pkcs11.load(pykcs11_lib)
logger.info('Library loaded: %s' % pkcs11.getInfo().libraryDescription)

#Učitaj sve dostupe smart kartice ili sigurnosne tokene
slots = pkcs11.getSlotList(tokenPresent=True)

if (len(slots) == 0):
    logger.warn('There are no slots with tokens (cards)')

for slot in slots:
    try:
        #Token i kartica nisu nužno ista stvar, jedna kartica može imati više tokena
        #Učitaj sve dostupene tokene i informacije o njima
        slot_info = pkcs11.getSlotInfo(slot)
        slot_mechanisms = pkcs11.getMechanismList(slot)
        token_info = pkcs11.getTokenInfo(slot)
        logger.info('\nSlot %i (%s) mechanism list: %s\
      \n>>> Token %s serial number: %s <<<\
      \n------------------------------------------------------------------------------------------------------'
                    % (slot, slot_info.slotDescription.strip(), ', '.join(slot_mechanisms), token_info.label.strip(), token_info.serialNumber))

        #Inicijaliziraj konekciju prema kartici
        session = pkcs11.openSession(slot)
        #Logirajte se u karticu sa svojim privatnim podatcima, unutar stringa potrebno je upisati vaš login kod.
        session.login('') #potrebno unijeti svoj pin za pristup OI

        objects = session.findObjects()
        for obj in objects:
            #Pronađi sve dostupne atribute na tokenu
            attr = session.getAttributeValue(obj, all_attr)
            attr = dict(zip(map(PyKCS11.CKA.get, all_attr), attr))
            cert = None

            #Ispiši podržane atribute i izvuci certifikat ako postoji
            if (PyKCS11.CKO[attr['CKA_CLASS']] in ['CKO_PUBLIC_KEY', 'CKO_PRIVATE_KEY']):
                logger.info('Certificate:\
          \nLabel: %s\
          \nClass: %s'
                            % (attr['CKA_LABEL'], PyKCS11.CKO[attr['CKA_CLASS']]))
                logger.debug('Skipping!')
                continue
            else:
                logger.info('Certificate:\
          \nLabel: %s\
          \nClass: %s\
          \nType: %s\
          \nValue: %s'
                            % (attr['CKA_LABEL'], PyKCS11.CKO[attr['CKA_CLASS']], PyKCS11.CKC[attr['CKA_CERTIFICATE_TYPE']], binascii.hexlify(bytearray(attr['CKA_VALUE']))))
                cert = x509.load_der_x509_certificate(bytes(attr['CKA_VALUE']))

            try:
                #Ako postoji atribut privatni ključ, pokušavamo ga pohraniti u zasebnu varijablu.
                private_key = session.findObjects([
                    (PyKCS11.CKA_CLASS, PyKCS11.CKO_PRIVATE_KEY)
                ])[0]

                #Potpisujemo tekst ili dokument sa privatnim ključem.
                logger.debug(
                    'Signing %s data with CKO_PRIVATE_KEY...' % data_to_sign)
                #Potpisujemo hash sa privatnim ključem
                signature = bytes(session.sign(private_key, data_to_sign))
                logger.info('Data %s signed:\n%s' % (
                    data_to_sign, binascii.hexlify(bytearray(signature))))

                #Izvlačimo javni ključ za dekripciju i verifikaciju potpisa
                public_key = session.findObjects([
                    (PyKCS11.CKA_CLASS, PyKCS11.CKO_PUBLIC_KEY)
                ])[0]

                #Verifikacija potpisa sa javnim ključem
                logger.info(
                    'Verifying signature with CKO_PUBLIC_KEY...' % data_to_sign)
                if session.verify(public_key, data_to_sign, signature):
                    logger.info('==> Signature OK!')
                else:
                    logger.warn('==> Signature NOT OK!')
            except Exception as e:
                logger.error(e)
    except Exception as e:
        logger.error(e)
